var gulp = require('gulp'),
    sass = require('gulp-sass'),
    uglifyJS = require('gulp-uglifyjs');

var config = {
    app: './app',
    dist: './dist'
};

gulp.task('test', function () {
    console.log('Gulp is working!');
});

gulp.task('sass', function () {
    return gulp.src(config.app + '/sass/**/*.sass')
        .pipe(sass())
        .pipe(gulp.dest(config.dist + '/css'));
});

gulp.task('js', function () {
    return gulp.src(config.app + '/js/**/*.js')
        .pipe(uglifyJS())
        .pipe(gulp.dest(config.dist + '/js'));
});
