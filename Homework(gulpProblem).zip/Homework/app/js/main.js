function my(message) {
    console.log(message);
}

my('JS is working!');